#ifndef WORLD_H
#define WORLD_H

#include <conf.h>

#ifdef __cplusplus
extern "C" {
#endif

D_API void world();


#ifdef __cplusplus
}
#endif

#endif
