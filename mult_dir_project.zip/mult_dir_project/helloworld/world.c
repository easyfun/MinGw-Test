#define SHARE_LIB

#include <world.h>
#include <stdio.h>

void world()
{
	printf("This is world.\n");
}
