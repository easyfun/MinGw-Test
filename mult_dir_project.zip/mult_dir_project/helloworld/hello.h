#ifndef HELLO_H
#define HELLO_H

#include <conf.h>

#ifdef __cplusplus
extern "C" {
#endif

D_API void hello();

#ifdef __cplusplus
}
#endif

#endif
